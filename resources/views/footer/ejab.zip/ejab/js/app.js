// ScrollReveal().reveal(".animated", { delay: 500 });
ScrollReveal().reveal(".animated", { scale: 0.1 });
